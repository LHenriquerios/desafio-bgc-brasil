# desafio-bgc-brasil
Um web scraper que busca os produtos mais vendidos da Amazon usando serviços da AWS, incluindo o AWS Lambda, o API Gateway e o Step Functions, para implantar minha aplicação.

const chromium = require('chrome-aws-lambda');
const puppeteer = require('puppeteer-core');
const AWS = require('aws-sdk');

const s3 = new AWS.S3();

exports.hello = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify({ message: 'Hello World!' })
  };
}

exports.getProductData = async (event, context) => {
  const executablePath = await chromium.executablePath;
  process.env.PUPPETEER_EXECUTABLE_PATH = executablePath;
  const browser = await puppeteer.launch({
    args: chromium.args,
    executablePath,
  });
  const page = await browser.newPage();
  await page.goto('https://www.amazon.com.br/');
  const title = await page.title();
  console.log(title);
  
  // Cria um buffer com o conteúdo da página
  const buffer = await page.pdf({
    format: 'A4',
    printBackground: true,
    margin: {
      top: '1cm',
      right: '1cm',
      bottom: '1cm',
      left: '1cm'
    }
  });
  
  // Define o nome do arquivo e o bucket S3
  const fileName = `amazon_${new Date().toISOString()}.pdf`;
  const bucketName = 'puppeteer_bucket';
  
  // Upload do arquivo para o S3
  await s3.putObject({
    Bucket: bucketName,
    Key: fileName,
    Body: buffer
  }).promise();
  
  // Retorna o título da página
  return {
    statusCode: 200,
    body: JSON.stringify(title)
  }
}

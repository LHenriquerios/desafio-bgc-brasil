const puppeteer = require('puppeteer');
const chromium = require('chrome-aws-lambda');

module.exports.hello = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Go Serverless v1.0! Your function executed successfully!',
        input: event,
      },
      null,
      2
    ),
  };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};


module.exports.getProductData = async (event) => {
  const url = 'https://www.amazon.com.br/bestsellers';

  const browser = await chromium.puppeteer.launch({
    executablePath: await chromium.executablePath,
  });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: 'networkidle0' });

  const result = {};
  const categories = await page.$$eval('div#zg_tabs div#zg_centerListWrapper', (elements) => {
    return elements.map((element) => element.querySelector('div.a-section h3.a-size-medium').textContent.trim());
  });

  for (const category of categories) {
    result[category] = [];

    const items = await page.$$(`div#zg_tabs div#zg_centerListWrapper div.a-section h3.a-size-medium:has-text("${category}") ~ span.zg-item`);
    for (let i = 0; i < items.length && i < 3; i++) {
      const name = await items[i].$eval('div.p13n-sc-truncated', (element) => element.textContent.trim());
      const rating = await items[i].$eval('div.a-icon-row span.a-icon-alt', (element) => element.textContent.trim());
      const price = await items[i].$eval('span.p13n-sc-price', (element) => element.textContent.trim());

      result[category].push({ name, rating, price });
    }
  }

  await browser.close();

  return {
    statusCode: 200,
    body: JSON.stringify(result),
  };
};
